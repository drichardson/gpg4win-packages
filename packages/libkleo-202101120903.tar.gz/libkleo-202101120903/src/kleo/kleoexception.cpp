/* -*- mode: c++; c-basic-offset:4 -*-
    exception.cpp

    This file is part of libkleopatra, the KDE keymanagement library
    SPDX-FileCopyrightText: 2008 Klarälvdalens Datakonsult AB

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#include "kleoexception.h"

Kleo::Exception::~Exception() throw() {}
