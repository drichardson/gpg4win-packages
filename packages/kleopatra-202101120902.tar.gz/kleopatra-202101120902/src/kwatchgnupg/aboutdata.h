/*
    aboutdata.h

    This file is part of Kleopatra, the KDE keymanager
    SPDX-FileCopyrightText: 2004 Klarälvdalens Datakonsult AB

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#ifndef ABOUTDATA_H
#define ABOUTDATA_H

#include <KAboutData>

class AboutData : public KAboutData
{
public:
    AboutData();
};

#endif // ABOUTDATA_H
