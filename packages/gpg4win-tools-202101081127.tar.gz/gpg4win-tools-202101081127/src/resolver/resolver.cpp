/* Copyright (C) 2018 by Intevation GmbH <info@intevation.de>
 *
 * This file is free software under the GNU GPL (v>=2)
 * and comes with ABSOLUTELY NO WARRANTY!
 * See LICENSE.txt for details.
 */

#include "resolver.h"

#include "util/overlay.h"

#include <QApplication>
#include <QCommandLineParser>
#include <QDebug>

#include <Libkleo/Enum>
#include <Libkleo/KeyResolver>

#include <iostream>

class Resolver::Private
{
public:
    Private(Resolver *qq): q(qq) {
    }

    void printResolvedKeys(const Kleo::KeyResolver *kr) {
        const auto sigMap = kr->signingKeys();
        for (const auto fmt: sigMap.keys()) {
            for (const auto key: sigMap[fmt]) {
                std::string fmtStr;
                if (fmt & Kleo::AnySMIME) {
                    fmtStr = "smime";
                } else {
                    fmtStr = "openpgp";
                }
                if (!key.isNull()) {
                    std::cout << "sig:" << fmtStr << ":"
                        << key.primaryFingerprint() << std::endl;
                }
            }
        }
        const auto encMap = kr->encryptionKeys();
        for (const auto fmt: encMap.keys()) {
            for (const auto mbox: encMap[fmt].keys()) {
                for (const auto key: encMap[fmt][mbox]) {
                    std::string fmtStr;
                    if (fmt & Kleo::AnySMIME) {
                        fmtStr = "smime";
                    } else {
                        fmtStr = "openpgp";
                    }
                    if (!key.isNull()) {
                        std::cout << "enc:" << fmtStr << ":"
                            << key.primaryFingerprint() << ":" << mbox.toUtf8().constData()
                            << std::endl;
                    }
                }
            }
        }
    }

    void newOverlay(WId wid, const QString &text)
    {
        m_overlay = std::shared_ptr<Overlay>(new Overlay(wid, text));
    }

    void newResolver(const QCommandLineParser &parser) {
        const auto proto = parser.value(QStringLiteral("protocol")).toLower();
        Kleo::CryptoMessageFormat format;
        if (proto == QStringLiteral("cms")) {
            format = Kleo::AnySMIME;
        } else if (proto == QStringLiteral("pgp")) {
            format = Kleo::AnyOpenPGP;
        } else {
            format = Kleo::AutoFormat;
        }

        const auto preferredVal = parser.value(QStringLiteral("preferred-protocol")).toLower();
        GpgME::Protocol preferred = GpgME::UnknownProtocol;
        if (preferredVal == QStringLiteral("cms")) {
            preferred = GpgME::CMS;
        } else if (preferredVal == QStringLiteral("pgp")) {
            preferred = GpgME::OpenPGP;
        }

        QMap <Kleo::CryptoMessageFormat, QMap <QString, QStringList> > overrides;

        for (const QString &oride: parser.values("override")) {
            const QStringList split = oride.split(QLatin1Char(':'));
            Kleo::CryptoMessageFormat fmt = Kleo::AutoFormat;
            if (split.size() < 2 || split.size() > 3) {
                qDebug() << "Invalid override format";
                std::cout << "cancel" << std::endl;
                qApp->quit();
            }

            if (split.size() == 3) {
                const QString fmtStr = split[2].toLower();
                if (fmtStr == "inlineopenpgp") {
                    fmt = Kleo::InlineOpenPGPFormat;
                } else if (fmtStr == "openpgpmime") {
                    fmt = Kleo::OpenPGPMIMEFormat;
                } else if (fmtStr == "smime") {
                    fmt = Kleo::SMIMEFormat;
                } else if (fmtStr == "smimeopaque") {
                    fmt = Kleo::SMIMEOpaqueFormat;
                } else if (fmtStr == "anyopenpgp") {
                    fmt = Kleo::AnyOpenPGP;
                } else if (fmtStr == "anysmime") {
                    fmt = Kleo::AnySMIME;
                } else if (fmtStr == "auto") {
                    fmt = Kleo::AutoFormat;
                } else {
                    qDebug() << "Invalid override format string";
                    std::cout << "cancel" << std::endl;
                    qApp->quit();
                }
            }
            const QStringList fingerprints = split[1].split(QLatin1Char(','));

            auto map = overrides.value(fmt);
            map.insert(split[0], fingerprints);
            overrides.insert(fmt, map);
            qDebug () << "Passing overrides" << fingerprints << split[0];
        }

        const auto recps = parser.positionalArguments();
        auto *kr = new Kleo::KeyResolver (!recps.isEmpty() || parser.isSet(QStringLiteral("encrypt")) /* encrypt */,
                                          parser.isSet(QStringLiteral("sign")) /*sign*/,
                                          format /* CryptoMesssageFormat */,
                                          parser.isSet("allowMixed")/* AllowMixed */);

        kr->setRecipients(recps);
        kr->setSender(parser.value("sender"));
        kr->enableNagging(true);
        kr->setOverrideKeys(overrides);
        kr->setPreferredProtocol(preferred);

        connect (kr, &Kleo::KeyResolver::keysResolved, q, [this, kr] (bool success, bool sendUnencrypted) {
            if (!success) {
                std::cout << "cancel" << std::endl;
            } else if (sendUnencrypted) {
                std::cout << "unencrypted" << std::endl;
            } else {
                printResolvedKeys(kr);
            }
            delete kr;
            qApp->quit();
        });
        kr->setDialogWindowFlags(Qt::Window |
                                 Qt::CustomizeWindowHint |
                                 Qt::WindowTitleHint |
                                 Qt::WindowCloseButtonHint);
        kr->start(parser.isSet(QStringLiteral("alwaysShow")), m_overlay.get());
    }
    Resolver *q;
    std::shared_ptr<Overlay> m_overlay;
};

Resolver::Resolver(int &argc, char *argv[]) :
    QApplication(argc, argv),
    d(new Private(this))
{

}

QString Resolver::newInstance(const QCommandLineParser &parser,
                              const QString &workingDirectry)
{
    const auto hwnd = parser.value(QStringLiteral("hwnd"));
    if (!hwnd.isEmpty()) {
        bool ok;
        WId id = (WId) hwnd.toInt(&ok);
        if (!ok) {
            std::cerr << "invalid hwnd value" << std::endl;
            exit(EXIT_FAILURE);
        }
        d->newOverlay(id, parser.value(QStringLiteral("overlayText")));
    }
    d->newResolver(parser);

    return QString();
}
